package edu.dao;

public interface IDao {
	
	public String add(Object object);
    
    public String delete(Object object);
    
    public String find(Object object);
    
}

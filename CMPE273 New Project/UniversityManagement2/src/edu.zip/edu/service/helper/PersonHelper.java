package edu.service.helper;

public class PersonHelper {
	
	private String addPerson(String firstname, String lastname, String address, String city, String state, int zipCode, String courseList)
	{
		return null;
	}
	
	private String deletePerson(int personId)
	{
		return null;
	}
	
}

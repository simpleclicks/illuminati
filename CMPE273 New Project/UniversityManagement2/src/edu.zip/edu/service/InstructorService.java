package edu.service;

import edu.db.entity.*;

public class InstructorService {
	public String addInstructor(String instructorId,String firstname, String lastname, String address,
			String city, String state, int zipCode, String courseList, 
			String department, String meetingTime )
	{
		return null;
	}
	
	public String deleteInstructor(String instructorId)
	{
		return null;
	}
}

package edu.service;

public class CourseService {
	public String addCourse(String courseId, String courseName, String courseSection, String location)
	{
		return null;
	}
	
	public String deleteCourse(String courseId)
	{
		return null;
	}
}

package edu.db.entity;

public class Student extends Person{

	private long studentId;

	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	
}
